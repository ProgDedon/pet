CREATE DATABASE IF NOT EXISTS onlinepet DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE onlinepet;

CREATE TABLE IF NOT EXISTS admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO admins (name, email, password_hash) VALUES
('Store Admin', 'admin@onlinepet.local', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');


CREATE TABLE IF NOT EXISTS pets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  breed VARCHAR(150) NOT NULL,
  type VARCHAR(80) NOT NULL,
  age INT UNSIGNED NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  description TEXT NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(150) NOT NULL,
  customer_email VARCHAR(150) NOT NULL,
  total_amount DECIMAL(12,2) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  pet_id INT UNSIGNED NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO pets (name, breed, type, age, price, description, image_url) VALUES
('Marley', 'Golden Retriever', 'Dog', 2, 850.00, 'A playful golden retriever who loves fetch and belly rubs.', 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=800&q=80'),
('Luna', 'Siamese', 'Cat', 1, 420.00, 'A clever and curious kitten with bright blue eyes.', 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=800&q=80'),
('Coco', 'Cockatiel', 'Bird', 3, 120.00, 'A cheerful bird that loves to whistle and sit on shoulders.', 'https://images.unsplash.com/photo-1501706362039-c6e809839b5c?auto=format&fit=crop&w=800&q=80'),
('Buddy', 'Beagle', 'Dog', 4, 630.00, 'Friendly and curious, Buddy is always up for an adventure.', 'https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=800&q=80'),
('Mia', 'Persian', 'Cat', 2, 480.00, 'A calm companion with a soft coat and sweet personality.', 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=800&q=80'),
('Sunny', 'Golden Macaw', 'Bird', 2, 320.00, 'Bright and social, Sunny loves to talk and play games.', 'https://images.unsplash.com/photo-1516382799247-4e92a1134cbd?auto=format&fit=crop&w=800&q=80');
