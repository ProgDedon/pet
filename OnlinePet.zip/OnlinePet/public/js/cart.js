document.addEventListener('DOMContentLoaded', () => {
  const removeButtons = document.querySelectorAll('.remove-item-button');
  removeButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const petId = button.dataset.petId;
      const form = document.querySelector(`#remove-form-${petId}`);
      if (form) form.submit();
    });
  });
});
